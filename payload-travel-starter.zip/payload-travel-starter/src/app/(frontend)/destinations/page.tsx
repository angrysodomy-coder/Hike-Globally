import type { Metadata } from 'next'
import React from 'react'
import { getDestinations, getPublishedTrips } from '@/lib/queries'
import { DestinationCard } from '@/components/destinations/DestinationCard'

export const metadata: Metadata = {
  title: 'Destinations | Himalaya Travel',
  description: 'Explore the regions we operate in — and the trips that take you there.',
}

export const revalidate = 86400

export default async function DestinationsPage() {
  const [destinations, trips] = await Promise.all([getDestinations(), getPublishedTrips()])

  const tripCounts = new Map<number, number>()
  for (const trip of trips) {
    const id = typeof trip.destination === 'object' ? trip.destination.id : trip.destination
    tripCounts.set(id, (tripCounts.get(id) ?? 0) + 1)
  }

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-4xl font-bold text-gray-900">Destinations</h1>
      <p className="mt-2 max-w-2xl text-gray-600">
        Every region we operate in, with the trips that take you there.
      </p>
      <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {destinations.map((destination) => (
          <DestinationCard
            key={destination.id}
            destination={destination}
            tripCount={tripCounts.get(destination.id) ?? 0}
          />
        ))}
      </div>
    </main>
  )
}
