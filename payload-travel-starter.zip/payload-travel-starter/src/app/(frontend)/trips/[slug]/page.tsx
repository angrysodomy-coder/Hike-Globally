import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import React from 'react'
import { getPayloadClient, getTripBySlug } from '@/lib/queries'
import { redirectOrNotFound } from '@/lib/redirects'
import { generateTripMeta } from '@/lib/generateMeta'
import { tripJsonLd } from '@/lib/structuredData'
import { LivePreviewListener } from '@/components/LivePreviewListener'
import { TripDetail } from '@/components/trips/TripDetail'

type Args = { params: Promise<{ slug: string }> }

// Safety-net ISR; on-demand revalidation (afterChange hook) is the primary mechanism.
export const revalidate = 86400
export const dynamicParams = true

export async function generateStaticParams() {
  const payload = await getPayloadClient()
  const trips = await payload.find({
    collection: 'trips',
    where: { _status: { equals: 'published' } },
    select: { slug: true },
    limit: 1000,
    pagination: false,
  })
  return trips.docs.map(({ slug }) => ({ slug }))
}

export async function generateMetadata({ params }: Args): Promise<Metadata> {
  const { slug } = await params
  const trip = await getTripBySlug(slug)
  return generateTripMeta(trip)
}

export default async function TripPage({ params }: Args) {
  const { slug } = await params
  const { isEnabled: draft } = await draftMode()
  const trip = await getTripBySlug(slug)

  if (!trip) return redirectOrNotFound(`/trips/${slug}`)

  return (
    <>
      {draft && <LivePreviewListener />}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(tripJsonLd(trip)) }}
      />
      <TripDetail trip={trip} />
    </>
  )
}
