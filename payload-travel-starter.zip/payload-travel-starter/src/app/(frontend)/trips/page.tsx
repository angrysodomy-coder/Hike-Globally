import type { Metadata } from 'next'
import React from 'react'
import { getPublishedTrips } from '@/lib/queries'
import { TripCard } from '@/components/trips/TripCard'

export const metadata: Metadata = {
  title: 'Trips & Packages | Himalaya Travel',
  description:
    'Hand-crafted treks, tours and expeditions. Browse itineraries, departures and prices.',
}

// Safety-net ISR; the 'trips' cache tag is purged on publish for instant updates.
export const revalidate = 86400

export default async function TripsPage() {
  const trips = await getPublishedTrips()

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-4xl font-bold text-gray-900">Trips &amp; Packages</h1>
      <p className="mt-2 max-w-2xl text-gray-600">
        Every itinerary below is managed in the CMS — publish a change and this page updates in
        seconds.
      </p>
      {trips.length === 0 ? (
        <p className="mt-12 rounded-xl border border-dashed border-gray-300 p-12 text-center text-gray-500">
          No published trips yet. Run <code>pnpm seed</code> or publish one in <code>/admin</code>.
        </p>
      ) : (
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {trips.map((trip) => (
            <TripCard key={trip.id} trip={trip} />
          ))}
        </div>
      )}
    </main>
  )
}
