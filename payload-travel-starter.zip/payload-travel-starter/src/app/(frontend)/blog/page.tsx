import type { Metadata } from 'next'
import React from 'react'
import { getPublishedPosts } from '@/lib/queries'
import { PostCard } from '@/components/blog/PostCard'

export const metadata: Metadata = {
  title: 'Travel Blog | Himalaya Travel',
  description: 'Trekking guides, gear advice and stories from the trail.',
}

// Safety-net ISR; the 'posts' cache tag is purged on publish for instant updates.
export const revalidate = 86400

export default async function BlogPage() {
  const posts = await getPublishedPosts()

  return (
    <main className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-4xl font-bold text-gray-900">Travel Blog</h1>
      <p className="mt-2 max-w-2xl text-gray-600">
        Guides, gear advice and stories from the trail.
      </p>
      {posts.length === 0 ? (
        <p className="mt-12 rounded-xl border border-dashed border-gray-300 p-12 text-center text-gray-500">
          No published posts yet. Run <code>pnpm seed:content</code> or publish one in{' '}
          <code>/admin</code>.
        </p>
      ) : (
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </main>
  )
}
