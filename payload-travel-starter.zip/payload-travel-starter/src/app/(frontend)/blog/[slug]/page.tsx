import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import React from 'react'
import { RichText } from '@payloadcms/richtext-lexical/react'
import { getPayloadClient, getPostBySlug } from '@/lib/queries'
import { redirectOrNotFound } from '@/lib/redirects'
import { generatePostMeta } from '@/lib/generateMeta'
import { postJsonLd } from '@/lib/structuredData'
import { formatDate } from '@/lib/formatters'
import { LivePreviewListener } from '@/components/LivePreviewListener'
import { PayloadImage } from '@/components/PayloadImage'
import { TripCard } from '@/components/trips/TripCard'
import type { Category, Trip } from '@/payload-types'

type Args = { params: Promise<{ slug: string }> }

export const revalidate = 86400
export const dynamicParams = true

export async function generateStaticParams() {
  const payload = await getPayloadClient()
  const posts = await payload.find({
    collection: 'posts',
    where: { _status: { equals: 'published' } },
    select: { slug: true },
    limit: 1000,
    pagination: false,
  })
  return posts.docs.map(({ slug }) => ({ slug }))
}

export async function generateMetadata({ params }: Args): Promise<Metadata> {
  const { slug } = await params
  const post = await getPostBySlug(slug)
  return generatePostMeta(post)
}

export default async function PostPage({ params }: Args) {
  const { slug } = await params
  const { isEnabled: draft } = await draftMode()
  const post = await getPostBySlug(slug)

  if (!post) return redirectOrNotFound(`/blog/${slug}`)

  const categories = (post.categories ?? []).filter(
    (c): c is Category => typeof c === 'object' && c !== null,
  )
  const relatedTrips = (post.relatedTrips ?? []).filter(
    (t): t is Trip => typeof t === 'object' && t !== null && t._status === 'published',
  )

  return (
    <article>
      {draft && <LivePreviewListener />}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(postJsonLd(post)) }}
      />

      {/* Hero */}
      <header className="relative h-[50vh] min-h-[360px] w-full">
        <PayloadImage media={post.heroImage} sizeName="hero" fill priority sizes="100vw" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-3xl px-6 pb-10 text-white">
          {categories.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <span
                  key={c.id}
                  className="rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-gray-800"
                >
                  {c.title}
                </span>
              ))}
            </div>
          )}
          <h1 className="mt-3 text-3xl font-bold md:text-5xl">{post.title}</h1>
          <p className="mt-3 text-sm text-white/80">
            {post.publishedAt && formatDate(post.publishedAt)}
            {post.authorName && ` · ${post.authorName}`}
          </p>
        </div>
      </header>

      {/* Body */}
      <div className="prose prose-gray mx-auto max-w-3xl px-6 py-12">
        <RichText data={post.content} />
      </div>

      {/* Cross-sell: related trips */}
      {relatedTrips.length > 0 && (
        <aside className="mx-auto max-w-6xl px-6 pb-16">
          <h2 className="text-2xl font-bold text-gray-900">Trips featured in this article</h2>
          <div className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {relatedTrips.map((trip) => (
              <TripCard key={trip.id} trip={trip} />
            ))}
          </div>
        </aside>
      )}
    </article>
  )
}
