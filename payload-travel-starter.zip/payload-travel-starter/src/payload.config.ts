import path from 'path'
import { fileURLToPath } from 'url'
import { buildConfig } from 'payload'
import { postgresAdapter } from '@payloadcms/db-postgres'
import { vercelBlobStorage } from '@payloadcms/storage-vercel-blob'
import { lexicalEditor } from '@payloadcms/richtext-lexical'
import { seoPlugin } from '@payloadcms/plugin-seo'
import { redirectsPlugin } from '@payloadcms/plugin-redirects'
import { nodemailerAdapter } from '@payloadcms/email-nodemailer'
import sharp from 'sharp'

import { Users } from '@/collections/Users'
import { Media } from '@/collections/Media'
import { Categories } from '@/collections/Categories'
import { Destinations } from '@/collections/Destinations'
import { Posts } from '@/collections/Posts'
import { Trips } from '@/collections/Trips'
import { Pages } from '@/collections/Pages'
import { Testimonials } from '@/collections/Testimonials'
import { Inquiries } from '@/collections/Inquiries'
import { Header } from '@/globals/Header'
import { Footer } from '@/globals/Footer'
import { generatePreviewPath } from '@/lib/generatePreviewPath'
import { revalidateRedirects, revalidateRedirectsDelete } from '@/hooks/revalidateRedirects'

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)

export default buildConfig({
  serverURL: process.env.NEXT_PUBLIC_SERVER_URL,
  secret: process.env.PAYLOAD_SECRET || '',
  admin: {
    user: Users.slug,
    importMap: { baseDir: path.resolve(dirname) },
    livePreview: {
      url: ({ data, collectionConfig }) =>
        generatePreviewPath({
          slug: typeof data?.slug === 'string' ? data.slug : '',
          collection: (collectionConfig?.slug ?? 'pages') as 'pages' | 'posts' | 'trips',
        }),
      collections: ['pages', 'posts', 'trips'],
      breakpoints: [
        { label: 'Mobile', name: 'mobile', width: 375, height: 667 },
        { label: 'Tablet', name: 'tablet', width: 768, height: 1024 },
        { label: 'Desktop', name: 'desktop', width: 1440, height: 900 },
      ],
    },
  },
  editor: lexicalEditor(),
  collections: [
    Users,
    Media,
    Categories,
    Destinations,
    Posts,
    Trips,
    Pages,
    Testimonials,
    Inquiries,
  ],
  globals: [Header, Footer],
  // Email: enabled only when SMTP env vars are set; without them Payload logs
  // emails to the console (fine for local dev). Used by the Inquiries
  // notification hook and Payload's own password-reset emails.
  email: process.env.SMTP_HOST
    ? nodemailerAdapter({
        defaultFromAddress: process.env.SMTP_FROM || 'noreply@example.com',
        defaultFromName: 'Himalaya Travel',
        transportOptions: {
          host: process.env.SMTP_HOST,
          port: Number(process.env.SMTP_PORT || 587),
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
        },
      })
    : undefined,
  // node-postgres adapter: works identically against Neon/Vercel Postgres in
  // production AND any local or self-hosted Postgres in development.
  db: postgresAdapter({
    pool: { connectionString: process.env.POSTGRES_URL || '' },
  }),
  plugins: [
    vercelBlobStorage({
      // Disabled automatically when no token is set (pure-local dev → files in /media)
      enabled: Boolean(process.env.BLOB_READ_WRITE_TOKEN),
      collections: { media: true },
      token: process.env.BLOB_READ_WRITE_TOKEN || '',
    }),
    redirectsPlugin({
      collections: ['pages', 'posts', 'trips'],
      overrides: {
        admin: { group: 'Admin' },
        hooks: {
          afterChange: [revalidateRedirects],
          afterDelete: [revalidateRedirectsDelete],
        },
      },
    }),
    seoPlugin({
      collections: ['pages', 'posts', 'trips'],
      uploadsCollection: 'media',
      tabbedUI: true,
      generateTitle: ({ doc }) =>
        doc?.title ? `${doc.title} | Himalaya Travel` : 'Himalaya Travel',
      generateURL: ({ doc, collectionSlug }) => {
        const base = process.env.NEXT_PUBLIC_SERVER_URL || ''
        const prefix =
          collectionSlug === 'posts' ? '/blog' : collectionSlug === 'trips' ? '/trips' : ''
        const slug = doc?.slug === 'home' ? '' : `/${doc?.slug ?? ''}`
        return collectionSlug === 'pages' ? `${base}${slug}` : `${base}${prefix}/${doc?.slug ?? ''}`
      },
    }),
  ],
  sharp,
  typescript: { outputFile: path.resolve(dirname, 'payload-types.ts') },
})
