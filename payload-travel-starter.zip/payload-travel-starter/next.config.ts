import { withPayload } from '@payloadcms/next/withPayload'
import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      // Vercel Blob public CDN URLs (production media)
      { protocol: 'https', hostname: '*.public.blob.vercel-storage.com' },
      // Local dev without a Blob token: Payload serves media from the app itself
      { protocol: 'http', hostname: 'localhost' },
      { protocol: 'http', hostname: '127.0.0.1' },
    ],
  },
}

export default withPayload(nextConfig)
